
/*
function getFilter(){
    let start_date = $('.date-input-start').first().val();
    let end_date = $('.date-input-end').first().val();

    if(start_date != '' && end_date != ''){

    } else {
        alert('Please fill all empty spaces');
    }
}

function detectSubmit(){
    $('.submit-date-button').click(function(){
        getFilter();
    });
}
*/

function control_input(){
    let input_start = createElement('input', ['date-input-start'], []);
    input_start.type = 'date';
    input_start.max = new Date().toISOString().split("T")[0];
    input_start.style.marginRight = '20px';
    input_start.name = 'date-input-start';
    let input_end = createElement('input', ['date-input-end'], []);
    input_end.type = 'date';
    input_end.max = new Date().toISOString().split("T")[0];
    input_end.style.marginRight = '40px';
    input_end.name = 'date-input-end';

    let submit_button = createElement('input', ['submit-date-button'], []);
    submit_button.value = 'Filtrar';
    submit_button.type = 'submit';
    submit_button.name = 'filtrar';
    
    let content = createElement('div', ['content-date'], [input_start.outerHTML, input_end.outerHTML, submit_button.outerHTML]);
    content.style.display = 'flex';
    content.style.justifyContent = 'center';
    content.style.marginTop = '30px';

    $(content).appendTo('.content-date-form');
}



function createElement(Type, ClassName, Content) {
    let elem = document.createElement(Type);

    if (ClassName != null) {
        ClassName.forEach(function (elemClass) {
            $(elem).addClass(elemClass);
        });
    }

    if (Content != null) {
        Content.forEach(function (elemContent) {
            elem.innerHTML += elemContent;
        });
    }

    return elem;
}

control_input();