function verCamposUsuario(idUsuario){
    location.href= "panelUsuario.html?idUsuario="+idUsuario;
}